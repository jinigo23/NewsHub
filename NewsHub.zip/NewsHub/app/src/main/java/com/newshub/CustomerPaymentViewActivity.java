package com.newshub;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class CustomerPaymentViewActivity extends AppCompatActivity {

    private ListView paymentListView;
    private ArrayList<CustomerPayments> paymentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_customer_payment_view);

        paymentListView = (ListView) findViewById (R.id.customerPaymentListView);
        paymentList = NewsDBHelper.getInstance (this).getCustomerPayments ( );
        CustomerPaymentAdapter adapter = new CustomerPaymentAdapter (this, paymentList);
        paymentListView.setAdapter (adapter);
    }

    @Override
    protected void onRestart() {
        super.onRestart ( );
        finish ( );
        startActivity (getIntent ( ));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed ( );
        finish ( );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ( ).inflate (R.menu.brands_view_menu, menu);
        return super.onCreateOptionsMenu (menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId ( )) {
            case R.id.brands_add:
                Intent intent = new Intent (CustomerPaymentViewActivity.this, CustomerPaymentAddActivity.class);
                startActivity (intent);
        }
        return super.onOptionsItemSelected (item);
    }
}
