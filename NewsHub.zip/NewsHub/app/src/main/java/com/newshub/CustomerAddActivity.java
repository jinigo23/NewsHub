package com.newshub;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CustomerAddActivity extends AppCompatActivity {

    private EditText customer_Name, joined_Date, customer_Place;
    DatePickerDialog datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_customer_add);

        customer_Name = (EditText) findViewById (R.id.customerName);
        joined_Date = (EditText) findViewById (R.id.joinedDate);
        joined_Date.setClickable (true);
        customer_Place = (EditText) findViewById (R.id.customerPlace);

        joined_Date.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance ( );
                int mDay = calendar.get (Calendar.DAY_OF_MONTH);
                int mMonth = calendar.get (Calendar.MONTH);
                int mYear = calendar.get (Calendar.YEAR);
                datePicker = new DatePickerDialog (CustomerAddActivity.this, new DatePickerDialog.OnDateSetListener ( ) {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        joined_Date.setText (day + "/" + (month + 1) + "/" + year);
                    }
                }, mYear, mMonth, mDay);
                datePicker.show ( );
            }
        });

        Intent intent = getIntent ( );
        int customer_ID = intent.getIntExtra ("Customer_ID", 0);
        String cName = intent.getStringExtra ("Customer_Name");
        String jDate = intent.getStringExtra ("Joined_Date");
        String cPlace = intent.getStringExtra ("Customer_Place");

        Log.d ("Fetched Details", "Fetched items :: " + cName + "\t" + jDate + "\t" + cPlace);

        if (customer_ID != 0) {
            customer_Name.setText (cName);
            joined_Date.setText (jDate);
            customer_Place.setText (cPlace);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ( ).inflate (R.menu.brands_add_menu, menu);
        return super.onCreateOptionsMenu (menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId ( )) {
            case R.id.saveBrand:
                String customerName = customer_Name.getText ( ).toString ( ).trim ( );
                String joinedDate = joined_Date.getText ( ).toString ( );
                String customerPlace = customer_Place.getText ( ).toString ( ).trim ( );

                SimpleDateFormat dateFormat = new SimpleDateFormat ("dd/mm/yyyy");
                String date = dateFormat.format (new Date ( ));

                if (customerName.length ( ) == 0 && joinedDate.length ( ) == 0 && customerPlace.length ( ) == 0) {
                    Toast.makeText (getApplicationContext ( ), "All fields are requred", Toast.LENGTH_SHORT).show ( );
                } else {
                    Intent intentCustomer = getIntent ( );
                    int customer_ID = intentCustomer.getIntExtra ("Customer_ID", 0);

                    if (customer_ID == 0) {
                        long isInserted = NewsDBHelper.getInstance (this).insertCustomerDetails (customerName, joinedDate, date, customerPlace);
                        if (isInserted >= 1) {
                            Toast.makeText (getApplicationContext ( ), "Saved succesfully", Toast.LENGTH_SHORT).show ( );
                            Log.d ("Customer Details", "Inserted items :: " + customerName + "\t" + joinedDate + "\t" + customerPlace);
                            Intent intent = new Intent (CustomerAddActivity.this, CustomerViewActivity.class);
                            startActivity (intent);
                            finish ( );
                        } else {
                            Log.d ("Brand Details", "Inserting error ");
                        }
                    } else {
                        boolean isUpdated = NewsDBHelper.getInstance (this).updateCustomerDetails (customer_ID, customerName, joinedDate, date, customerPlace);
                        if (isUpdated == true) {
                            Toast.makeText (getApplicationContext ( ), "Updated succesfully", Toast.LENGTH_SHORT).show ( );
                            Log.d ("Updated", "Updated : " + customerName);
                            finish ( );
                        }
                    }
                }
                break;

            case R.id.deleteBrand:
                Intent intent = getIntent ( );
                long myID = intent.getIntExtra ("Customer_ID", 0);
                if (myID != 0) {
                    NewsDBHelper.getInstance (this).deleteCustomer (myID);
                    Toast.makeText (getApplicationContext ( ), "Item deleted Successfully", Toast.LENGTH_SHORT).show ( );
                    finish ( );
                } else {
                    Toast.makeText (getApplicationContext ( ), "No items found", Toast.LENGTH_SHORT).show ( );
                }
                break;
        }
        return super.onOptionsItemSelected (item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed ( );
        finish ( );
    }
}
