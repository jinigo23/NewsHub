package com.newshub;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class MenuAdapter extends BaseAdapter {

    private Context context;
    private int imgThumbs[];
    private String txtTitles[];

    public MenuAdapter(Context context, int[] imgThumbs, String[] txtTitles) {
        this.context = context;
        this.imgThumbs = imgThumbs;
        this.txtTitles = txtTitles;
    }

    @Override
    public int getCount() {
        return txtTitles.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View gridView;
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService (context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {
            gridView = layoutInflater.inflate (R.layout.menu_grid_items, null);
            ImageView gridImg = (ImageView) gridView.findViewById (R.id.gridImg);
            TextView gridTxt = (TextView) gridView.findViewById (R.id.gridTxt);
            gridImg.setImageResource (imgThumbs[position]);
            gridTxt.setText (txtTitles[position]);
        } else {
            gridView = (View) convertView;
        }
        return gridView;
    }
}
