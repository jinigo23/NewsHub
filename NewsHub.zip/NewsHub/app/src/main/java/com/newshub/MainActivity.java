package com.newshub;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private GridView gridMenu;
    private int imgThumbs[] = {R.drawable.icons8_news_100, R.drawable.icons8_customer_100, R.drawable.icons8_place_marker_100, R.drawable.icons8_business_report_100, R.drawable.icons8_rupee_100, R.drawable.icons8_rupee_100};
    private String txtTitles[] = {"Brands", "Customers", "Area", "Customer Report", "My payment", "Customer payment"};
    private boolean doubleBackPressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        NewsDBHelper.getInstance (this);
        Log.d ("Create table", "Created :: \t" + NewsDBHelper.getInstance (this));

        gridMenu = (GridView) findViewById (R.id.menuGrid);
        MenuAdapter adapter = new MenuAdapter (this, imgThumbs, txtTitles);
        gridMenu.setAdapter (adapter);

        gridMenu.setOnItemClickListener (new AdapterView.OnItemClickListener ( ) {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                PopupMenu popupMenu = new PopupMenu (MainActivity.this, view);
                popupMenu.getMenuInflater ( ).inflate (R.menu.brand_popup_menu, popupMenu.getMenu ( ));

                switch (position) {
                    case 0:
                        popupMenu.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
                            @Override
                            public boolean onMenuItemClick(MenuItem menuItem) {
                                int seletedItem = menuItem.getItemId ( );
                                switch (seletedItem) {
                                    case R.id.addPopup:
                                        Intent intentAdd = new Intent (MainActivity.this, BrandsAddActivity.class);
                                        startActivity (intentAdd);
                                        break;
                                    case R.id.viewPopup:
                                        Intent intentView = new Intent (MainActivity.this, BrandsViewActivity.class);
                                        startActivity (intentView);
                                        break;
                                    default:
                                        return false;
                                }
                                return true;
                            }
                        });
                        popupMenu.show ( );
                        break;

                    case 1:
                        popupMenu.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
                            @Override
                            public boolean onMenuItemClick(MenuItem menuItem) {
                                switch (menuItem.getItemId ( )) {
                                    case R.id.addPopup:
                                        Intent intentAdd = new Intent (MainActivity.this, CustomerAddActivity.class);
                                        startActivity (intentAdd);
                                        break;

                                    case R.id.viewPopup:
                                        Intent intentView = new Intent (MainActivity.this, CustomerViewActivity.class);
                                        startActivity (intentView);
                                        break;

                                    default:
                                        return false;
                                }
                                return true;
                            }
                        });
                        popupMenu.show ();
                        break;

                    case 2:
                        popupMenu.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
                            @Override
                            public boolean onMenuItemClick(MenuItem menuItem) {
                                switch (menuItem.getItemId ( )) {
                                    case R.id.addPopup:
                                        Intent intentAdd = new Intent (MainActivity.this, LocationAddActivity.class);
                                        startActivity (intentAdd);
                                        break;

                                    case R.id.viewPopup:
                                        Intent intentView = new Intent (MainActivity.this, LocationViewActivity.class);
                                        startActivity (intentView);
                                        break;

                                    default:
                                        return false;
                                }
                                return true;
                            }
                        });
                        popupMenu.show ();
                        break;

                    case 3:
                        Intent intentAdd = new Intent (MainActivity.this, CustomerReportActivity.class);
                        startActivity (intentAdd);
                        break;

                    case 4:
                        popupMenu.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
                            @Override
                            public boolean onMenuItemClick(MenuItem menuItem) {
                                int selectedItem = menuItem.getItemId ( );
                                switch (selectedItem) {
                                    case R.id.addPopup:
                                        Intent intentAdd = new Intent (MainActivity.this, MyPaymentsAddActivity.class);
                                        startActivity (intentAdd);
                                        break;

                                    case R.id.viewPopup:
                                        Intent intentView = new Intent (MainActivity.this, MyPaymentsViewActivity.class);
                                        startActivity (intentView);
                                        break;
                                    default:
                                        return false;
                                }
                                return true;
                            }
                        });
                        popupMenu.show ( );
                        break;

                    case 5:
                        Intent intentView = new Intent (MainActivity.this, CustomerPaymentSearchActivity.class);
                        startActivity (intentView);
//                        popupMenu.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
//                            @Override
//                            public boolean onMenuItemClick(MenuItem menuItem) {
//                                switch (menuItem.getItemId ( )) {
//                                    case R.id.addPopup:
//                                        Intent intentAdd = new Intent (MainActivity.this, CustomerPaymentAddActivity.class);
//                                        startActivity (intentAdd);
//                                        break;
//
//                                    case R.id.viewPopup:
//                                        Intent intentView = new Intent (MainActivity.this, CustomerPaymentViewActivity.class);
//                                        startActivity (intentView);
//                                        break;
//
//                                    default:
//                                        return false;
//                                }
//                                return true;
//                            }
//                        });
//                        popupMenu.show ();
                        break;

                }
//                }
//                if (position == 4) {
//                    PopupMenu popupMenu4 = new PopupMenu (MainActivity.this, view);
//                    popupMenu4.getMenuInflater ( ).inflate (R.menu.brand_popup_menu, popupMenu4.getMenu ( ));
//                    popupMenu4.setOnMenuItemClickListener (new PopupMenu.OnMenuItemClickListener ( ) {
//                        @Override
//                        public boolean onMenuItemClick(MenuItem menuItem) {
//                            switch (menuItem.getItemId ( )) {
//                                case R.id.addPopup:
//                                    Intent intentAdd = new Intent (MainActivity.this, MyPaymentsAddActivity.class);
//                                    startActivity (intentAdd);
//                                    break;
//
//                                case R.id.viewPopup:
//                                    Intent intentView = new Intent (MainActivity.this, MyPaymentsViewActivity.class);
//                                    startActivity (intentView);
//                                    break;
//                            }
//
//                            return true;
//                        }
//                    });
//                    popupMenu4.show ();
//                }


            }
        });
    }

    @Override
    public void onBackPressed() {
        if (doubleBackPressed) {
            super.onBackPressed ( );
            return;
        }
        this.doubleBackPressed = true;
        Toast.makeText (getApplicationContext ( ), "Back press again to exit", Toast.LENGTH_SHORT).show ( );

        new Handler ( ).postDelayed (new Runnable ( ) {
            @Override
            public void run() {
                doubleBackPressed = false;
            }
        }, 2000);
    }
}
